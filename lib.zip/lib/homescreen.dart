import 'package:flutter/material.dart';

import 'package:cinema_inventory/action_tile.dart';
import 'package:cinema_inventory/add_equipment.dart';
import 'package:cinema_inventory/equipment_list.dart';
import 'package:cinema_inventory/equipment_repo.dart';
import 'package:cinema_inventory/helpers.dart';
import 'package:cinema_inventory/inventory_stats.dart';
import 'package:cinema_inventory/summary_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final Stream<InventoryStats> _stats = EquipmentRepository.instance
      .watchStats();

  void _push(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Equipment Manager'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Inventory Summary',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          StreamBuilder<InventoryStats>(
            stream: _stats,
            builder: (context, snap) {
              if (snap.hasError) {
                return Text('Could not load summary: ${snap.error}');
              }
              final s = snap.data;
              return Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: SummaryCard(
                          title: 'Total equipment',
                          value: '${s?.total ?? 0}',
                          icon: Icons.inventory_2_outlined,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: SummaryCard(
                          title: 'Available',
                          value: '${s?.available ?? 0}',
                          icon: Icons.check_circle_outline,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: SummaryCard(
                          title: 'Checked out',
                          value: '${s?.out ?? 0}',
                          icon: Icons.local_shipping_outlined,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: SummaryCard(
                          title: 'Overdue',
                          value: '${s?.late ?? 0}',
                          icon: Icons.warning_amber_outlined,
                        ),
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 24),
          const Text(
            'Manage Equipment',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          ActionTile(
            icon: Icons.add_box_outlined,
            title: 'Add equipment',
            subtitle: 'Register new gear and its daily rate',
            onTap: () => _push(const AddEquipmentScreen()),
          ),
          ActionTile(
            icon: Icons.list_alt,
            title: 'View equipment',
            subtitle: 'Browse all gear and its status',
            onTap: () => _push(const EquipmentListScreen()),
          ),
          ActionTile(
            icon: Icons.qr_code_scanner,
            title: 'Check out / return',
            subtitle: 'Scan a QR code to log a movement',
            onTap: () => showMessage(context, 'Coming soon'),
          ),
          ActionTile(
            icon: Icons.receipt_long_outlined,
            title: 'Rentals & reports',
            subtitle: 'Track amounts and gear movements',
            onTap: () => showMessage(context, 'Coming soon'),
          ),
        ],
      ),
    );
  }
}
